import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Note } from './note/note';

@Injectable()
export class NotesService {

  constructor(private http: HttpClient) {}

  addNote(note: Note) {
    return this.http.post<Note>('http://localhost:3000/notes', note);
  }

  getAllNotes() {
    return this.http.get<Array<Note>>('http://localhost:3000/notes');
  }

}
