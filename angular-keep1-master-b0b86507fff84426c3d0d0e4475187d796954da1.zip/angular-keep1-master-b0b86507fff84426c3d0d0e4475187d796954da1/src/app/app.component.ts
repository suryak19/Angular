import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Note } from './note/note';
import { NotesService } from './notes.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'app';

  constructor(private notesService: NotesService) {}

  note: Note = new Note();
  notes: Array<Note> = [];

  takeNotes() {
    this.notes.push(this.note);
    // console.log(this.notes);
    this.notesService.addNote(this.note).subscribe(
      data => {},
      err => {
        const index: number = this.notes.findIndex(note => note.title === this.note.title);
        this.notes.splice(index, 1);
      }
  );
    this.note = new Note();
    // console.log("Note Title - "+this.note.title+", Description -"+this.note.text);

  }

  ngOnInit() {
    this.notesService.getAllNotes().subscribe(
      data => this.notes = data,
      err => console.log(err)
    );
  }

}
